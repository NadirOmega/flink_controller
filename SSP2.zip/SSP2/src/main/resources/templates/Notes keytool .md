Notes:

keytool -genkeypair -alias flink.rest -keystore rest.keystore -dname "CN=flink-jobmanager-test-spring-2" -ext "SAN=dns:flink-jobmanager-rest-test-spring-2,dns:localhost,dns:flink-jobmanager-service-test-spring-2" -storepass rest_keystore_password -keyalg RSA -keysize 4096 -storetype PKCS12
keytool -exportcert -keystore rest.keystore -alias flink.rest -storepass rest_keystore_password -file flink.cer
keytool -importcert -keystore rest.truststore -alias flink.rest -storepass rest_truststore_password -file flink.cer -noprompt
keytool -v -list -storetype jks -keystore rest.keystore

keytool -genkeypair -alias flink.rest -keystore rest.keystore -dname "CN=*" -ext "SAN=dns:flink-jobmanager-rest-test-spring-2,dns:localhost,dns:flink-jobmanager-service-test-spring-2" -storepass rest_keystore_password -keyalg RSA -keysize 4096 -storetype PKCS12
keytool -exportcert -keystore rest.keystore -alias flink.rest -storepass rest_keystore_password -file flink.cer
keytool -importcert -keystore rest.truststore -alias flink.rest -storepass rest_truststore_password -file flink.cer -noprompt
keytool -v -list -storetype jks -keystore rest.keystore



keytool -genkeypair 
  -alias flink.internal 
  -keystore internal.keystore 
  -dname "CN=flink.internal" 
  -storepass internal_store_password 
  -keyalg RSA 
  -keysize 4096 
  -storetype PKCS12
