package com.example.backend.utils;

import org.yaml.snakeyaml.Yaml;

import java.io.InputStream;
import java.util.Map;

public class KubernetesUtils {

    private static final Yaml yaml = new Yaml();

    public static String applyTemplate(String templatePath, Map<String, String> replacements) {
        try (InputStream inputStream = KubernetesUtils.class.getResourceAsStream(templatePath)) {
            String template = new String(inputStream.readAllBytes());
            for (Map.Entry<String, String> replacement : replacements.entrySet()) {
                template = template.replace(replacement.getKey(), replacement.getValue());
            }
            return template;
        } catch (Exception e) {
            throw new RuntimeException("Error reading or applying template", e);
        }
    }
}
