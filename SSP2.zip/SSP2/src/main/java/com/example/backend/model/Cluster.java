package com.example.backend.model;

import lombok.*;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Cluster {

 
    private Long id;

    private String name;

    private TaskManager taskManagers;

    private JobManager jobManager;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	

	public TaskManager getTaskManagers() {
		return taskManagers;
	}

	public void setTaskManagers(TaskManager taskManagers) {
		this.taskManagers = taskManagers;
	}

	public JobManager getJobManager() {
		return jobManager;
	}

	public void setJobManager(JobManager jobManager) {
		this.jobManager = jobManager;
	}


}
