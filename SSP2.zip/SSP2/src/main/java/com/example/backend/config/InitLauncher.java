package com.example.backend.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.DependsOn;

import io.fabric8.kubernetes.api.model.apps.Deployment;
import io.fabric8.kubernetes.api.model.apps.DeploymentList;
import io.fabric8.kubernetes.client.KubernetesClient;
/*
@Configuration
@DependsOn("KubernetesConfig")

public class InitLauncher {
	@Autowired
	KubernetesConfig kubernetesConfig ;
	//KubernetesConfig kubernetesConfig = new KubernetesConfig();
	KubernetesClient kc ;
	public InitLauncher(){
		kc = kubernetesConfig.kubernetesClient();
		DeploymentList dpls =  kc.apps().deployments().inAnyNamespace().withLabel("role", "jobmanager").list();
		for(Deployment item : dpls.getItems()) {
			System.out.println(item.getMetadata().getName());
		}
		//System.out.println(kc.apps().deployments().inAnyNamespace().withLabel("test", "hello").list());
	}
}*/
