package com.example.backend.utils;

import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Component;
import org.springframework.util.StreamUtils;

import io.fabric8.kubernetes.client.KubernetesClient;

import java.io.ByteArrayInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.Map;

@Component
public class YamlUtils {

	public static String readYamlFromResources(String fileName) {
		try (InputStream inputStream = YamlUtils.class.getClassLoader().getResourceAsStream(fileName)) {
			if (inputStream == null) {
				throw new RuntimeException("File not found in resources: " + fileName);
			}
			return new String(inputStream.readAllBytes());
		} catch (IOException e) {
			throw new RuntimeException("Error reading YAML file from resources", e);
		}
	}

	public static String replacePlaceholders(String yamlTemplate, Map<String, String> placeholderValues) {
		for (Map.Entry<String, String> entry : placeholderValues.entrySet()) {
			
			String placeholder = "\\{\\{" + entry.getKey() + "\\}\\}";
			System.out.println(placeholder);
			yamlTemplate = yamlTemplate.replaceAll(placeholder, entry.getValue());
		}
		return yamlTemplate;
	}

	public static void writeYamlToFile(String filledYaml, String filePath) {
		try (FileWriter writer = new FileWriter(filePath)) {
			writer.write(filledYaml);
		} catch (IOException e) {
			throw new RuntimeException("Error writing YAML to file", e);
		}
	}
}
