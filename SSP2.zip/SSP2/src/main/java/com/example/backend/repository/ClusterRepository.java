package com.example.backend.repository;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.example.backend.model.ClusterFullCluster;

public interface ClusterRepository extends JpaRepository<ClusterFullCluster, Long>{

	  List<ClusterFullCluster> findByNameContaining(String title);
	  
	
	   void deleteByName(String name);
}
