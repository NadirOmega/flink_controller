package com.example.backend.controller;

import com.example.backend.model.Cluster;

import com.example.backend.model.ClusterFullCluster;
import com.example.backend.service.ClusterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;



import java.util.List;
import java.util.Map;
@CrossOrigin
@RestController
@RequestMapping("/api/clusters")
public class ClusterController {

	@Autowired
	private ClusterService clusterService;

	@GetMapping
	public ResponseEntity<List<ClusterFullCluster>> getAllClusters() {
		List<ClusterFullCluster> clusters = clusterService.getAllCluster();
		return new ResponseEntity<>(clusters, HttpStatus.OK);
	}

	@GetMapping("/{id}")
	public ResponseEntity<ClusterFullCluster> getClusterById(@PathVariable("id") long id) throws Exception {
		System.out.println("getmapping id "+ id);
		ClusterFullCluster cluster = clusterService.getClusterById(id);
		return new ResponseEntity<>(cluster, HttpStatus.OK);
	}
	@DeleteMapping("/{id}")
	public ResponseEntity<String> deleteCluster(@PathVariable("id") long id) throws Exception {
		System.out.println("delete calling ");
		String clusterName = clusterService.getClusterById(id).getName();
		clusterService.deleteFullCluster(id);
		return new ResponseEntity<>(clusterName+" deleted", HttpStatus.ACCEPTED);
	}
	/*
    @PostMapping
    public ResponseEntity<Cluster> createCluster(@RequestBody Cluster cluster) {
        Cluster createdCluster = clusterService.createCluster(cluster);
        return new ResponseEntity<>(createdCluster, HttpStatus.CREATED);
    }*/
	@PostMapping

	public void createFullCluster(@RequestBody ClusterFullCluster cluster) {
		//System.out.println(cluster.toString());
		System.out.println(cluster.getId()+ " " +cluster.getName()+ " " +cluster.isSsl());
		//cluster.setName(String.valueOf(cluster.getId()));
		clusterService.createFllCluster(cluster);
		//ClusterFullCluster createdCluster = clusterService.createFllCluster(cluster);
	}
	

	/*
    @PostMapping
    public ResponseEntity<ClusterFullCluster> createFullCluster(@RequestBody ClusterFullCluster cluster) {
    	System.out.println(cluster.toString());
    	System.out.println(cluster.getName());
    	System.out.println(cluster.getTaskManagerNumber());
    	System.out.println(cluster.getId());
    	ClusterFullCluster createdCluster = clusterService.createFllCluster(cluster);
        // return new ResponseEntity<>(createdCluster, HttpStatus.CREATED);
    	 return new ResponseEntity<>(cluster, HttpStatus.CREATED);
    }*/

	@PutMapping("/{id}")
	public ResponseEntity<ClusterFullCluster> editCluster(@PathVariable("id") long id, @RequestBody ClusterFullCluster cluster) {
		ClusterFullCluster clusterFullCluster = clusterService.editFullCluster(id, cluster);
		return new ResponseEntity<>(cluster, HttpStatus.OK);
	}
	// Ajoutez d'autres méthodes pour la mise à jour et la suppression des clusters selon les besoins.
}
