package com.example.backend.model;

public enum JobManagerType {
    SESSION,
    DEPLOYMENT
}
