package com.example.backend.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Table(name = "Cluster")
public class ClusterFullCluster {



	@Id
	private Long id;

	@Column(name = "name")
	private String name;

	@Column(name = "taskManagerNumber")
	private int taskManagerNumber;

	@Column(name = "labels")
    private String labels;

	


	@Column(name = "annotations")
    private String annotations;
	 
	@Column(name = "config")
	private String config;

	@Column(name = "ssl")
	private boolean ssl;

	private static Long idAuto = Long.valueOf(0);


	public ClusterFullCluster() {

	}


	public ClusterFullCluster(Long id, String name, int taskManagerNumber) {
		super();
		this.id = id;
		this.name = name;
		this.taskManagerNumber = taskManagerNumber;
	}

	public ClusterFullCluster(Long id, String name, int taskManagerNumber,String labels, String annotations , String config, boolean ssl) {
		super();
		this.id = id;
		this.name = name;
		this.taskManagerNumber = taskManagerNumber;
		this.labels=labels;
		this.annotations=annotations;
		this.config = config;
		this.ssl=ssl;
	}


	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getTaskManagerNumber() {
		return taskManagerNumber;
	}

	public void setTaskManagerNumber(int taskManagerNumber) {
		this.taskManagerNumber = taskManagerNumber;
	}


	public String getConfig() {
		return config;
	}


	public void setConfig(String config) {
		this.config = config;
	}


	public static Long getIdAuto() {
		return idAuto;
	}


	public boolean isSsl() {
		return ssl;
	}


	public void setSsl(boolean ssl) {
		this.ssl = ssl;
	}


	public static void setIdAuto(Long idAuto) {
		ClusterFullCluster.idAuto = idAuto;
	}
	public String getLabels() {
		return labels;
	}


	public void setLabels(String labels) {
		this.labels = labels;
	}


	public String getAnnotations() {
		return annotations;
	}


	public void setAnnotations(String annotations) {
		this.annotations = annotations;
	}
	
	
}
