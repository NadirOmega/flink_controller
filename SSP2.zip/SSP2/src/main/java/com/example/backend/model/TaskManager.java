package com.example.backend.model;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TaskManager {

    private Long id;

    private String name;
    private String imageName;
    private int taskmanagerNb;
  
    private Cluster cluster;
}
