package com.example.backend.service;

import java.io.ByteArrayInputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.backend.config.KubernetesConfig;
import com.example.backend.model.Cluster;
import com.example.backend.model.ClusterFullCluster;
import com.example.backend.repository.ClusterRepository;
import com.example.backend.utils.KubernetesUtils;
import com.example.backend.utils.YamlUtils;

import io.fabric8.kubernetes.api.model.HasMetadata;
import io.fabric8.kubernetes.api.model.apps.Deployment;
import io.fabric8.kubernetes.api.model.apps.DeploymentList;
import io.fabric8.kubernetes.client.KubernetesClient;
import io.fabric8.kubernetes.client.dsl.FilterWatchListDeletable;

@Service
public class ClusterService {

    @Autowired
    private KubernetesClient kubernetesClient;

    // Utilitaire pour le remplacement des champs dans les fichiers YAML
    @Autowired
    private YamlUtils yamlUtils;
    
	@Autowired
	ClusterRepository clusterRepository;
	
	@Autowired
	KubernetesConfig kubernetesConfig ;
	//KubernetesConfig kubernetesConfig = new KubernetesConfig();
	KubernetesClient kc ;
	@PostConstruct
	public void InitLauncher(){
		System.out.println("###### DISCOVERING CLUSTERS ###");
		kc = kubernetesConfig.kubernetesClient();
		DeploymentList jobmanagers =  kc.apps().deployments().inAnyNamespace().withLabel("role", "jobmanager").list();
		FilterWatchListDeletable<Deployment, DeploymentList> taskmanagers =  kc.apps().deployments().inAnyNamespace().withLabel("role", "taskmanager");
		HashMap<Deployment, Deployment> clusters = new HashMap<Deployment, Deployment>();
		for(Deployment item : jobmanagers.getItems()) {
			Long id ;
			Map<String,String> labels ;
			id = Long.valueOf(item.getMetadata().getLabels().get("id"));
			int taskmanagernumber=0;
			try {
				 taskmanagernumber=taskmanagers.withLabel("id", String.valueOf(id)).list().getItems().get(0).getSpec().getReplicas();

			}catch(Exception e) {
				//do nothing
			}
			System.out.println(id  +"  "+item.getMetadata().getName().split("flink-jobmanager-")[1]+"  "+taskmanagernumber);
			
			ClusterFullCluster cluster = new ClusterFullCluster(
					id,item.getMetadata().getName().split("flink-jobmanager-")[1],taskmanagernumber);
			clusterRepository.save(cluster);
			System.out.println("#### Cluster Found" + item.getMetadata().getName());
		}
		//System.out.println(kc.apps().deployments().inAnyNamespace().withLabel("test", "hello").list());
		System.out.println("###### END  CLUSTERS DISCOVERING ###");
	}
	
	
    public List<ClusterFullCluster> getAllCluster() {
    	List<ClusterFullCluster> clusterList = new ArrayList<ClusterFullCluster>();
    	clusterRepository.findAll().forEach(clusterList::add);
    	return clusterList;
    }
   
    public ClusterFullCluster getClusterById(Long id) throws Exception {
    	
    	Optional<ClusterFullCluster> tutorialData = clusterRepository.findById(id);

		if (tutorialData.isPresent()) {
			return tutorialData.get();
		} else {
			throw new Exception("Error on the objet "+ tutorialData.toString());
		}
    }
    
    public ClusterFullCluster editFullCluster(Long id ,  ClusterFullCluster newCluster) {
    	Optional<ClusterFullCluster> clusterFullCluster =clusterRepository.findById(id);
    	ClusterFullCluster temp = clusterFullCluster.get();
    	temp.setName(newCluster.getName());
    	temp.setTaskManagerNumber(newCluster.getTaskManagerNumber());
    	return temp; 
    }
    public void deleteFullCluster(Long id) throws Exception {
    	//String clusterName= 
		KubernetesClient kubernetesClient = new KubernetesConfig().kubernetesClient();
		/*String clusterName= clusterRepository.getById(id).getName();
		kubernetesClient.apps().deployments().withName("flink-jobmanager-"+clusterName).cascading(true).delete();
		boolean rez= kubernetesClient.apps().deployments().inNamespace("stream").withName("flink-taskmanager-"+clusterName).cascading(true).delete();
		kubernetesClient.services().inNamespace("stream").withName("flink-jobmanager-"+clusterName).delete();
		System.out.println("flink-jobmanager-"+clusterName);
		System.out.println(kubernetesClient.apps().deployments().inNamespace("stream").withName("flink-jobmanager-"+clusterName).get().getMetadata().toString());
		//clusterRepository.deleteById(id);*/
		//System.out.println("end");
		//this.clusterList.add(cluster);
		String templateFileName = "templates/fullClusterDeletor.yml";
		String yamlTemplate = YamlUtils.readYamlFromResources(templateFileName);
		Map<String, String> placeholderValues = new HashMap<>();
		placeholderValues.put("cluster-name", this.getClusterById(id).getName());
		String filledYaml = YamlUtils.replacePlaceholders(yamlTemplate, placeholderValues);
		String outputFilePath = "output/generated"+"deletor"+".yaml";

		// Write the filled YAML to a new file
		YamlUtils.writeYamlToFile(filledYaml, outputFilePath);
		
		List<HasMetadata> result = kubernetesClient.load(new ByteArrayInputStream(filledYaml.getBytes(StandardCharsets.UTF_8))).get();
		// Apply Kubernetes Resources
		
		kubernetesClient.resourceList(result).inNamespace("stream").delete();
		
		clusterRepository.deleteById(id);

    }
    
    public ClusterFullCluster createFllCluster(ClusterFullCluster cluster) {
        // Création du JobManager
    	
    	//KubernetesClient kc= kubernetesClient();
		
		String templateFileName = "templates/fullCluster.yml";

		// Read the YAML template from the resources folder
		String yamlTemplate = YamlUtils.readYamlFromResources(templateFileName);

		// Define placeholder values
		Map<String, String> placeholderValues = new HashMap<>();
		placeholderValues.put("cluster-name", cluster.getName());
		placeholderValues.put("taskmanager-number", String.valueOf(cluster.getTaskManagerNumber()));
		placeholderValues.put("id", String.valueOf(cluster.getId()));
		if(cluster.isSsl()) {
			placeholderValues.put("flink-ssl", "true");
		}else {
			placeholderValues.put("flink-ssl", "false");
		}
		StringBuilder labels_deployment=new StringBuilder("");
		StringBuilder labels_deployment_template=new StringBuilder("");
		String tab4="    ";
		for(String item : cluster.getLabels().split("\\n")) {
			labels_deployment.append(tab4).append(item).append("\n");
			labels_deployment_template
			.append(tab4)
			.append(tab4)
			.append(item).append("\n");
			System.out.println(item);
			System.out.println("########");
		}
		labels_deployment.deleteCharAt(labels_deployment.length()-1);
		labels_deployment_template.deleteCharAt(labels_deployment_template.length()-1);
		placeholderValues.put("deployment-labels",labels_deployment.toString());
		placeholderValues.put("deployment-template-labels",labels_deployment_template.toString());
		
		StringBuilder annotations_deployment=new StringBuilder("");
		StringBuilder annotations_deployment_template=new StringBuilder("");
		for(String item : cluster.getAnnotations().split("\\n")) {
			annotations_deployment.append(tab4).append(item).append("\n");;
			annotations_deployment_template
			.append(tab4)
			.append(tab4)
			.append(item).append("\n");
		}
		annotations_deployment.deleteCharAt(annotations_deployment.length()-1);
		annotations_deployment_template.deleteCharAt(annotations_deployment_template.length()-1);
		placeholderValues.put("deployment-annotations",annotations_deployment.toString());
		placeholderValues.put("deployment-template-annotations",annotations_deployment_template.toString());
		
		// Replace placeholders in the YAML template
		String filledYaml = YamlUtils.replacePlaceholders(yamlTemplate, placeholderValues);

		// Specify the path to save the generated YAML file
		//String outputFilePath = "generated.yaml";

		// Write the filled YAML to a new file
		//YamlUtils.writeYamlToFile(filledYaml, outputFilePath);
		KubernetesClient kubernetesClient = new KubernetesConfig().kubernetesClient();
		
		String outputFilePath = "output/generated"+cluster.getName()+".yaml";

		// Write the filled YAML to a new file
		YamlUtils.writeYamlToFile(filledYaml, outputFilePath);
		
		List<HasMetadata> result = kubernetesClient.load(new ByteArrayInputStream(filledYaml.getBytes(StandardCharsets.UTF_8))).get();
		// Apply Kubernetes Resources
		
		kubernetesClient.resourceList(result).inNamespace("stream").createOrReplace() ;
		System.out.println("end");
		clusterRepository.save(cluster);
		return cluster;
        //createJobManager();
/*
        // Création des TaskManagers
        createTaskManagers();

        // Création de la ConfigMap
        createConfigMap();

        // Création des Services
        createServices();
*/
        // Implémentez le reste de la logique métier ici

       // return cluster;
    }

    /**
     * DEFAULT LAUNCH
     * @param cluster
     * @return
     */
    
    public void createCluster() {
        // Création du JobManager
    	
    	//KubernetesClient kc= kubernetesClient();
		
		String templateFileName = "templates/all.yml";

		// Read the YAML template from the resources folder
		String yamlTemplate = YamlUtils.readYamlFromResources(templateFileName);

		// Define placeholder values
		Map<String, String> placeholderValues = new HashMap<>();
		placeholderValues.put("flink-config", "flink-config");
		placeholderValues.put("flink-jobmanager-rest", "flink-jobmanager-rest");
		placeholderValues.put("flink-jobmanager-service", "flink-jobmanager");
		placeholderValues.put("flink-jobmanager", "flink-jobmanager");
		placeholderValues.put("flink-taskmanager", "flink-taskmanager");
		
		// Replace placeholders in the YAML template
		String filledYaml = YamlUtils.replacePlaceholders(yamlTemplate, placeholderValues);

		// Specify the path to save the generated YAML file
		//String outputFilePath = "generated.yaml";

		// Write the filled YAML to a new file
		//YamlUtils.writeYamlToFile(filledYaml, outputFilePath);
		KubernetesClient kubernetesClient = new KubernetesConfig().kubernetesClient();
		
		String outputFilePath = "generated.yaml";

		// Write the filled YAML to a new file
		YamlUtils.writeYamlToFile(filledYaml, outputFilePath);
		
		List<HasMetadata> result = kubernetesClient.load(new ByteArrayInputStream(filledYaml.getBytes(StandardCharsets.UTF_8))).get();
		// Apply Kubernetes Resources
		
		kubernetesClient.resourceList(result).inNamespace("stream").createOrReplace() ;
		System.out.println("end");
        //createJobManager();
/*
        // Création des TaskManagers
        createTaskManagers();

        // Création de la ConfigMap
        createConfigMap();

        // Création des Services
        createServices();
*/
        // Implémentez le reste de la logique métier ici

       // return cluster;
    }
    
    private void createJobManager() {
        // Utilisation du template YAML pour le JobManager
    	
    
    }
/*
    private void createTaskManagers() {
        // Utilisation du template YAML pour les TaskManagers
        String taskManagerTemplate = KubernetesUtils.applyTemplate("/templates/taskmanager-template.yaml", Map.of("name", cluster.getName()));
        kubernetesClient.load(new ByteArrayInputStream(taskManagerTemplate.getBytes(StandardCharsets.UTF_8))).createOrReplace();
        // Implémentez la création de plusieurs TaskManagers si nécessaire
    }

    private void createConfigMap() {
        // Utilisation du template YAML pour la ConfigMap
        String configMapTemplate = KubernetesUtils.applyTemplate("/templates/configmap-template.yaml", Map.of("name", cluster.getName()));
        kubernetesClient.load(new ByteArrayInputStream(configMapTemplate.getBytes(StandardCharsets.UTF_8))).createOrReplace(); 
        }

    private void createServices() {
        // Utilisation du template YAML pour les Services
        String serviceTemplate = KubernetesUtils.applyTemplate("/templates/service-template.yaml", Map.of("name", cluster.getName()));
        kubernetesClient.load(new ByteArrayInputStream(serviceTemplate.getBytes(StandardCharsets.UTF_8))).createOrReplace();
        // Implémentez la création d'autres services si nécessaire
    }
    */
    /**
     * DEFAULT LAUNCH END
     * @param cluster
     * @return
     */
    
    
    public Cluster createCluster(Cluster cluster) {
        // Création du JobManager
        createJobManager(cluster);

        // Création des TaskManagers
        createTaskManagers(cluster);

        // Création de la ConfigMap
        createConfigMap(cluster);

        // Création des Services
        createServices(cluster);

        // Implémentez le reste de la logique métier ici

        return cluster;
    }
    
    
    private void createJobManager(Cluster cluster) {
        // Utilisation du template YAML pour le JobManager
        String jobManagerTemplate = KubernetesUtils.applyTemplate("/templates/jobmanager-template.yaml", Map.of("name", cluster.getName()));
        kubernetesClient.load(new ByteArrayInputStream(jobManagerTemplate.getBytes(StandardCharsets.UTF_8))).createOrReplace();
    }

    private void createTaskManagers(Cluster cluster) {
        // Utilisation du template YAML pour les TaskManagers
        String taskManagerTemplate = KubernetesUtils.applyTemplate("/templates/taskmanager-template.yaml", Map.of("name", cluster.getName()));
        kubernetesClient.load(new ByteArrayInputStream(taskManagerTemplate.getBytes(StandardCharsets.UTF_8))).createOrReplace();
        // Implémentez la création de plusieurs TaskManagers si nécessaire
    }

    private void createConfigMap(Cluster cluster) {
        // Utilisation du template YAML pour la ConfigMap
        String configMapTemplate = KubernetesUtils.applyTemplate("/templates/configmap-template.yaml", Map.of("name", cluster.getName()));
        kubernetesClient.load(new ByteArrayInputStream(configMapTemplate.getBytes(StandardCharsets.UTF_8))).createOrReplace(); 
        }

    private void createServices(Cluster cluster) {
        // Utilisation du template YAML pour les Services
        String serviceTemplate = KubernetesUtils.applyTemplate("/templates/service-template.yaml", Map.of("name", cluster.getName()));
        kubernetesClient.load(new ByteArrayInputStream(serviceTemplate.getBytes(StandardCharsets.UTF_8))).createOrReplace();
        // Implémentez la création d'autres services si nécessaire
    }
    /*
    
    public Cluster createClusterOld(Cluster cluster) throws IOException {
        // Créer un JobManager
    	
        createJobManager(cluster.getJobManager());

        // Créer des TaskManagers
       createTaskManagers(cluster.getTaskManagers());

        // Créer une ConfigMap pour la configuration de Flink
        createFlinkConfigMap(cluster);

        // Créer des Services
        createInternalService(cluster);
        createRestService(cluster);

        // Reste de la logique métier...

        return cluster;
    }
*/

  /*  private void createJobManager(JobManager jobManager) throws IOException {
        // Utilisation du templating pour créer un JobManager
        String jobManagerYaml = YamlUtils.populateTemplate("jobmanager-template.yaml", "name", jobManager.getName());
        YamlUtils.createResourceDeploy(this.kubernetesClient,jobManagerYaml);
        }*/
/*
    private void createTaskManagers(List<TaskManager> taskManagers) {
        for (TaskManager taskManager : taskManagers) {
            // Utilisation du templating pour créer un TaskManager
            String taskManagerYaml = yamlUtils.populateTemplate("taskmanager-template.yaml", "name", taskManager.getName());
            kubernetesClient.apps().deployments().createOrReplace(io.fabric8.kubernetes.api.model.apps.DeploymentBuilder.parseYaml(taskManagerYaml).build());
        }
    }

    private void createFlinkConfigMap(Cluster cluster) {
        // Utilisation du templating pour créer une ConfigMap
        String flinkConfigYaml = yamlUtils.populateTemplate("flink-configmap-template.yaml", "name", cluster.getName());
        kubernetesClient.configMaps().createOrReplace(io.fabric8.kubernetes.api.model.ConfigMapBuilder.parseYaml(flinkConfigYaml).build());
    }

    private void createInternalService(Cluster cluster) {
        // Utilisation du templating pour créer un Service interne
        String internalServiceYaml = yamlUtils.populateTemplate("internal-service-template.yaml", "name", cluster.getName());
        kubernetesClient.services().createOrReplace(io.fabric8.kubernetes.api.model.ServiceBuilder.parseYaml(internalServiceYaml).build());
    }

    private void createRestService(Cluster cluster) {
        // Utilisation du templating pour créer un Service REST
        String restServiceYaml = yamlUtils.populateTemplate("rest-service-template.yaml", "name", cluster.getName());
        kubernetesClient.services().createOrReplace(io.fabric8.kubernetes.api.model.ServiceBuilder.parseYaml(restServiceYaml).build());
    }

	public List<Cluster> getAllClusters() {
		// TODO Auto-generated method stub
		return null;
	}*/

    // Autres méthodes de service...
}
